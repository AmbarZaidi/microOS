void aboutMe()
{
	printStr(1,58," Spring Semester 2016 ",176);
		printStr(1,0," CSN-232: Operating Systems",176	);
		printStr(5,20,"Developed under:",63	);
		printStr(5,34,"Prof. Vaskar Raychoudhary",63);
		printStr(8,1,"Group",48);
		printStr(10,7,"                 14114009 - Ambar Zaidi                          ",63);
		printStr(11,7,"                 14114018 - Ashutosh Yadav                       ",63);
		printStr(12,7,"                 14114036 - Tirth Patel                          ",63);
		printStr(13,7,"                 14114063 - Sumit Kumar Singh                    ",63);
		printStr(16,1,"About",48);
		printStr(18,1,"This is an implementation of a simple OS where we have built a bootloader and   load a 32-bit kernel using it. Major components of project are:                 1.Bootloader                  2.Kernel                  3.Display driver",63);
}
